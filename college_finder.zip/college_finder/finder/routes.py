from finder import app
from flask import request,render_template,redirect,url_for,flash
from finder import db
from finder.forms import RegisterForm,searchform
from finder.models import College,Admin

@app.route('/register',methods=['GET','POST'])
def register():
	form=RegisterForm()
	if form.validate_on_submit():
		hostel_facility=request.form.get('place')
		admin=int(form.admin_id.data)
		p_word=form.password1.data
		t=0
		for i in Admin.query.all():
			if(i.admin_id==admin):
				if(p_word==i.password):
					college=College(collegename=form.collegename.data,country=form.country.data,address=form.address.data,hostel=hostel_facility,courses=form.courses.data,exams=form.exams.data,placements=form.placements.data,email=form.email.data,phnno=form.phno.data)
					db.session.add(college)
					db.session.commit()
					t=1
					flash('The College is Registered Successfully', category='success')
					return redirect(url_for('home'))
		if t==0:
			flash('The Admin details are not correct.Unauthorised Access denied', category='danger')
	if form.errors != {}:
		for err_msg in form.errors.values():
			flash(f'There was an error with creating a user: {err_msg}', category='danger')

	if form.errors!={}:
		print(form.errors)
		print("FAIL")
	return render_template('login.html',form=form)





@app.route('/', methods=['GET', 'POST'])
@app.route('/home', methods=['GET', 'POST'])
def home():
	form=searchform()
	avail_colleges=[]
	for i in College.query.all():
		avail_colleges.append(i)



	if request.method == 'POST':
		if request.form.get('action1') == 'Search':
			srch_country=form.search_country.data
			if srch_country == '':
				for i in College.query.all():
					avail_colleges.append(i)
			else:
				s=[]
				for i in College.query.all():
					if(i.country == srch_country):
						s.append(i)
				if s==[]:
					flash('There is no data on the country try some other!',category='danger')
				else:
					avail_colleges=s

			
			
			
	return render_template('home.html',form=form,colleges=avail_colleges)








@app.route('/about')
def about():
	return render_template('about.html')

@app.route('/contactus')
def contactus():
	return render_template('contact.html')