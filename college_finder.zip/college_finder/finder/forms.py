from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField
from wtforms.widgets import TextArea
from wtforms.validators import Length, EqualTo, Email, DataRequired, ValidationError


class RegisterForm(FlaskForm):

	collegename=StringField(label='College Name:',validators=[Length(min=2, max=30), DataRequired()])
	country=StringField(label='Country:',validators=[Length(min=2, max=30), DataRequired()])
	address=StringField(label='Address',validators=[Length(min=2, max=30), DataRequired()])
	hostel=StringField(label='Hostel:')
	
	courses=StringField(label='Courses Offered:',widget=TextArea(),validators=[Length(min=2, max=500), DataRequired()])
	exams=StringField(label='Exams Required:',widget=TextArea(),validators=[Length(min=2, max=500), DataRequired()])
	placements=StringField(label='Placements Offers:',widget=TextArea(),validators=[Length(min=2, max=500), DataRequired()])
	
	email = StringField(label='Email Address:',validators=[Email(), DataRequired()])
	phno=StringField(label='Phone Number:',validators=[Length(max=15),DataRequired()])


	admin_id=StringField(label='Admin Id:',validators=[Length(min=2, max=30), DataRequired()])
	password1 = PasswordField(label='Password:',validators=[Length(min=6), DataRequired()])

	
	
	submit = SubmitField(label='Register')

class searchform(FlaskForm):
	search_country=StringField(label='Enter Country',validators=[Length(min=2, max=30)])