from finder import db

class College(db.Model):
	id=db.Column(db.Integer, primary_key=True)
	collegename=db.Column(db.String(length=30),nullable=False)
	country=db.Column(db.String(length=30),nullable=False)
	address=db.Column(db.String(length=30),nullable=False)
	hostel=db.Column(db.String(length=20),nullable=False,default='Yes')

	courses=db.Column(db.String(length=500),nullable=False)
	exams=db.Column(db.String(length=500),nullable=False)
	placements=db.Column(db.String(length=500),nullable=False)

	email=db.Column(db.String(length=30),nullable=False,unique=True)
	phnno=db.Column(db.String(length=30),nullable=False,unique=True)


class Admin(db.Model):
	id = db.Column(db.Integer,primary_key=True)
	admin_id = db.Column(db.Integer,nullable=False,unique=True)
	password=db.Column(db.String(length=30),nullable=False)
	